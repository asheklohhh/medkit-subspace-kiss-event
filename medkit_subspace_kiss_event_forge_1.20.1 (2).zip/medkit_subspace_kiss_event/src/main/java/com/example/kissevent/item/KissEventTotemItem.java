package com.example.kissevent.item;

import com.example.kissevent.registry.ModEntities;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class KissEventTotemItem extends Item {
    public KissEventTotemItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (!level.isClientSide && level instanceof ServerLevel serverLevel) {
            Vec3 look = player.getLookAngle();
            double centerX = player.getX() + look.x * 2.0D;
            double centerZ = player.getZ() + look.z * 2.0D;
            double y = player.getY();

            var medkit = ModEntities.KISS_CHARACTER.get().create(serverLevel);
            var subspace = ModEntities.KISS_CHARACTER.get().create(serverLevel);

            if (medkit != null && subspace != null) {
                medkit.setVariant(0);
                subspace.setVariant(1);
                medkit.moveTo(centerX - 0.95D, y, centerZ, -90.0F, 0.0F);
                subspace.moveTo(centerX + 0.95D, y, centerZ, 90.0F, 0.0F);
                serverLevel.addFreshEntity(medkit);
                serverLevel.addFreshEntity(subspace);
                serverLevel.sendParticles(net.minecraft.core.particles.ParticleTypes.HAPPY_VILLAGER,
                        centerX, y + 2.0D, centerZ, 12, 0.7D, 0.5D, 0.7D, 0.02D);
            }

            if (!player.getAbilities().instabuild) {
                stack.shrink(1);
            }
            player.displayClientMessage(Component.literal("Medkit + Subspace: Kiss Event!").withStyle(ChatFormatting.LIGHT_PURPLE), true);
        }

        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
