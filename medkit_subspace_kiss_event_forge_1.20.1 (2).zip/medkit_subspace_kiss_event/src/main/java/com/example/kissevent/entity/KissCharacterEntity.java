package com.example.kissevent.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.level.Level;

public class KissCharacterEntity extends PathfinderMob {
    private static final EntityDataAccessor<Byte> VARIANT =
            SynchedEntityData.defineId(KissCharacterEntity.class, EntityDataSerializers.BYTE);

    public KissCharacterEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setNoAi(true);
        this.setNoGravity(true);
        this.moveControl = new MoveControl(this);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(VARIANT, (byte) 0);
    }

    public void setVariant(int variant) {
        this.entityData.set(VARIANT, (byte) (variant == 0 ? 0 : 1));
    }

    public int getVariant() {
        return this.entityData.get(VARIANT);
    }

    @Override
    public void tick() {
        super.tick();

        // Medkit approaches from the left; Subspace approaches from the right.
        if (this.tickCount <= 36) {
            double step = 0.018D;
            this.setPos(this.getX() + (getVariant() == 0 ? step : -step),
                    this.getY(), this.getZ());
        }

        // Turn toward the other character.
        this.setYRot(getVariant() == 0 ? -90.0F : 90.0F);
        this.yBodyRot = this.getYRot();
        this.yHeadRot = this.getYRot();

        if (this.tickCount > 36 && this.tickCount < 105 && this.tickCount % 7 == 0
                && this.level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.HEART,
                    this.getX(), this.getY() + 1.65D, this.getZ(),
                    2, 0.22D, 0.18D, 0.12D, 0.0D);
        }

        if (this.tickCount >= 120) {
            this.discard();
        }
    }

    @Override
    public boolean isPersistenceRequired() {
        return true;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putByte("KissVariant", this.entityData.get(VARIANT));
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("KissVariant")) {
            this.entityData.set(VARIANT, tag.getByte("KissVariant"));
        }
    }
}
