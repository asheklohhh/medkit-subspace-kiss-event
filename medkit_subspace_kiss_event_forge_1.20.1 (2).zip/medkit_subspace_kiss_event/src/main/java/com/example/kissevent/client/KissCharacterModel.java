package com.example.kissevent.client;

import com.example.kissevent.KissEventMod;
import com.example.kissevent.entity.KissCharacterEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

public class KissCharacterModel extends EntityModel<KissCharacterEntity> {
    public static final net.minecraft.client.model.geom.ModelLayerLocation LAYER =
            new net.minecraft.client.model.geom.ModelLayerLocation(
                    new net.minecraft.resources.ResourceLocation(KissEventMod.MOD_ID, "kiss_character"), "main");

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart leftArm;
    private final ModelPart rightArm;
    private final ModelPart leftLeg;
    private final ModelPart rightLeg;

    public KissCharacterModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.leftArm = root.getChild("left_arm");
        this.rightArm = root.getChild("right_arm");
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 32).addBox(-4, 0, -2, 8, 12, 4),
                PartPose.offset(0, 0, 0));
        root.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4, -8, -4, 8, 8, 8)
                        // Simple angular horns/antlers silhouette.
                        .texOffs(32, 0).addBox(-7, -13, -1, 3, 6, 3)
                        .texOffs(32, 0).addBox(4, -13, -1, 3, 6, 3)
                        .texOffs(44, 0).addBox(-1, -10, -4.5F, 2, 3, 1),
                PartPose.offset(0, 0, 0));
        root.addOrReplaceChild("left_arm",
                CubeListBuilder.create().texOffs(24, 32).addBox(-1, -2, -2, 4, 12, 4),
                PartPose.offset(5, 2, 0));
        root.addOrReplaceChild("right_arm",
                CubeListBuilder.create().texOffs(24, 32).addBox(-3, -2, -2, 4, 12, 4),
                PartPose.offset(-5, 2, 0));
        root.addOrReplaceChild("left_leg",
                CubeListBuilder.create().texOffs(40, 32).addBox(-2, 0, -2, 4, 12, 4),
                PartPose.offset(2, 12, 0));
        root.addOrReplaceChild("right_leg",
                CubeListBuilder.create().texOffs(40, 32).addBox(-2, 0, -2, 4, 12, 4),
                PartPose.offset(-2, 12, 0));

        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(KissCharacterEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        head.yRot = netHeadYaw * ((float)Math.PI / 180F);
        head.xRot = headPitch * ((float)Math.PI / 180F);
        float approach = Mth.clamp(entity.tickCount / 36.0F, 0.0F, 1.0F);
        leftArm.xRot = -0.15F - approach * 0.25F;
        rightArm.xRot = -0.15F - approach * 0.25F;
        leftLeg.xRot = Mth.cos(limbSwing * 0.65F) * limbSwingAmount * 0.35F;
        rightLeg.xRot = Mth.cos(limbSwing * 0.65F + (float)Math.PI) * limbSwingAmount * 0.35F;
    }

    @Override
    public void renderToBuffer(com.mojang.blaze3d.vertex.PoseStack poseStack,
                               com.mojang.blaze3d.vertex.VertexConsumer buffer,
                               int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
