package com.example.kissevent.registry;

import com.example.kissevent.KissEventMod;
import com.example.kissevent.item.KissEventTotemItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, KissEventMod.MOD_ID);

    public static final RegistryObject<Item> KISS_EVENT_TOTEM = ITEMS.register(
            "kiss_event_totem",
            () -> new KissEventTotemItem(new Item.Properties().stacksTo(1))
    );
}
