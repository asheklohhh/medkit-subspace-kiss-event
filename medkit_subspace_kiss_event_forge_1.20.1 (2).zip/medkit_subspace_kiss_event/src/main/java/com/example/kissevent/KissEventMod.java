package com.example.kissevent;

import com.example.kissevent.registry.ModEntities;
import com.example.kissevent.registry.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(KissEventMod.MOD_ID)
public class KissEventMod {
    public static final String MOD_ID = "kiss_event";

    public KissEventMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITY_TYPES.register(bus);
    }
}
