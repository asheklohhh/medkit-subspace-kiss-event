package com.example.kissevent.registry;

import com.example.kissevent.KissEventMod;
import com.example.kissevent.entity.KissCharacterEntity;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber(modid = KissEventMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, KissEventMod.MOD_ID);

    public static final RegistryObject<EntityType<KissCharacterEntity>> KISS_CHARACTER =
            ENTITY_TYPES.register("kiss_character", () ->
                    EntityType.Builder.<KissCharacterEntity>of(KissCharacterEntity::new, MobCategory.MISC)
                            .sized(0.7F, 1.85F)
                            .clientTrackingRange(10)
                            .updateInterval(2)
                            .build("kiss_character"));
    @SubscribeEvent
    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(KISS_CHARACTER.get(), KissCharacterEntity.createAttributes().build());
    }
}
