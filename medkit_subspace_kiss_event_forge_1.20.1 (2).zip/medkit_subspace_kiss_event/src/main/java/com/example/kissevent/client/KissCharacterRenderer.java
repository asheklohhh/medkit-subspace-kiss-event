package com.example.kissevent.client;

import com.example.kissevent.KissEventMod;
import com.example.kissevent.entity.KissCharacterEntity;
import com.example.kissevent.registry.ModEntities;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = KissEventMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = net.minecraftforge.api.distmarker.Dist.CLIENT)
public class KissCharacterRenderer extends MobRenderer<KissCharacterEntity, KissCharacterModel> {
    private static final ResourceLocation MEDKIT =
            new ResourceLocation(KissEventMod.MOD_ID, "textures/entity/medkit.png");
    private static final ResourceLocation SUBSPACE =
            new ResourceLocation(KissEventMod.MOD_ID, "textures/entity/subspace.png");

    public KissCharacterRenderer(EntityRendererProvider.Context context) {
        super(context, new KissCharacterModel(context.bakeLayer(KissCharacterModel.LAYER)), 0.35F);
    }

    @Override
    public ResourceLocation getTextureLocation(KissCharacterEntity entity) {
        return entity.getVariant() == 0 ? MEDKIT : SUBSPACE;
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.KISS_CHARACTER.get(), KissCharacterRenderer::new);
    }

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(KissCharacterModel.LAYER, KissCharacterModel::createBodyLayer);
    }
}
