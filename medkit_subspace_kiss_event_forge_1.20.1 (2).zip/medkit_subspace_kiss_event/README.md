# Medkit & Subspace — Kiss Event

A Minecraft Forge **1.20.1** source project.

## What it adds
- A creative-mode item named **Heart of Chaos**.
- Right-clicking the item summons Medkit and Subspace in front of the player.
- The two stylized characters approach one another, pause for a kiss-event pose, emit heart particles, then disappear.
- The item is registered as `kiss_event:kiss_event_totem`.

## Build
Requirements: Java 17 (recommended for Forge 1.20.1) and Gradle 8.x. The Gradle Forge plugin and Minecraft dependencies must be downloaded on the first build, so internet access is required.

From this folder, run:

```bash
gradle build
```

If compilation succeeds, the installable mod jar will be created in `build/libs/`. This project archive does not include a precompiled mod jar.

For a development client, run:

```bash
gradle runClient
```

## Give yourself the item
```mcfunction
/give @p kiss_event:kiss_event_totem
```

## Notes
This is the editable source project, not a precompiled jar. The character artwork is represented by original low-resolution pixel textures and a shared blocky model; it is a stylized in-game interpretation of the supplied references.
